# Licenses

## Common Javascript

MIT or Apache 2.0

## Android version

MIT or Apache 2.0

## iOS/macOS version

MIT only

based on Phonegap-SQLitePlugin by @davibe (Davide Bertola <dade@dadeb.it>) and @joenoon (Joe Noon <joenoon@gmail.com>)

includes and uses PSPDFThreadSafeMutableDictionary (PSPDFThreadSafeMutableDictionary.m <https://gist.github.com/steipete/5928916>) MIT license by @steipete (<https://gist.github.com/steipete>)

## Windows version

MIT or Apache 2.0

### SQLite3-WinRT

by @doo (doo GmbH)

MIT License

## SQLite3

Public domain
