import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editspecial',
  templateUrl: './editspecial.page.html',
  styleUrls: ['./editspecial.page.scss'],
})
export class EditspecialPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
